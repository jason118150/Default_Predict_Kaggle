#Default_train.sh
#!/bin/bash
python2.7 te.py $1
