#Default_train.sh
#!/bin/bash
python2.7 te1.py $1 $2
